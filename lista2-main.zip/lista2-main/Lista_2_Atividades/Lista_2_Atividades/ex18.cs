﻿
using System;

namespace Lista_2_Atividades
{
	
	public class ex18
	{
		public static void Main()
		{
			/*18. Escreva um programa em C# para criar um padrão como triângulo de
			ângulo reto com números iguais que repetirá um número em cada linha.
			O padrão é o seguinte:
			1
			22
			333
			4444*/
			
			int numero = 0;
			Console.WriteLine("Escreva um número:");
			numero = int.Parse(Console.ReadLine());
			
			Console.WriteLine("O padrão do triângulo de ângulo reto com números:");
			for (int  = 0;  < end; ++) {
				
			}
			
			Console.ReadKey(true);
		}
	}
}
